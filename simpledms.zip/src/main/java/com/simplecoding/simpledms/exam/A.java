package com.simplecoding.simpledms.exam;

public class A {
//    1. 스프링의 DI,IOC,AOP에 대해서 설명해주세요
//    DI:  객체간의 의존관계를 외부에서 주입하는 방식입니다.
//    IOC: 객체생성과 의존성 관련 기능을 개발자가 아닌 스프링 에서 관리해주는 개념입니다.
//    AOP: 공통 기능을 핵심 로직과 분리해서 재사용 가능하게 만드는 방식입니다.

//    2. 생성자 DI 와 컨트롤러를 만들려고 합니다.
//       아래 코드중 누락된 부분을 추가하세요

//    @RequiredArgsConstructor
//    @Controller
//    @RequestMapping("/dept")
//    public class DeptController{

//    서비스가져오기

//    private final DeptService deptService;}

}
