package com.simplecoding.simpledms.gallery.service;

import com.simplecoding.simpledms.gallery.dto.GalleryDto;
import com.simplecoding.simpledms.gallery.entity.Gallery;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
@Log4j2
@SpringBootTest
@EnableJpaAuditing
class GalleryServiceTest {
    @Autowired
    GalleryService galleryService;

    @Test
    void selectGalleryList() {
        String searchKeyword = "%4%";
        Pageable pageable = PageRequest.of(0, 3);
        Page<GalleryDto> page =
                galleryService.selectGalleryList(searchKeyword, pageable);
        log.info("테스트: "+page.getContent());
    }

    @Test
    void findById() {
        String uuid = "12345672";
        Gallery gallery = galleryService.findById(uuid);
        log.info(gallery);
    }

    @Test
    void deleteById() {
        String uuid = "12345672";
        galleryService.deleteById(uuid);
    }
}